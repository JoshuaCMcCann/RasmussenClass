<?php
// This is an example of config.php
$dbhost = 'us-cdbr-azure-central-a.cloudapp.net';
$dbuser = 'bdfe9fc383a9d7';
$dbpass = 'd1914894';
$dbname = 'jmccannwebdev';
?>
